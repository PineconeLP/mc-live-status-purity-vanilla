window.isNotificationSupported = function() {
    return window.Notification !== undefined;
}